<template>
#[[$END$]]#
</template>

<script lang="ts">
import { mixins } from 'vue-class-component'
import MainMixin from '@/mixins/main'
import { Component } from 'vue-property-decorator'

@Component({
name: "${COMPONENT_NAME}"
})
export default class ${COMPONENT_NAME} extends mixins(MainMixin) {

}
</script>

<style lang="stylus" scoped>

</style>